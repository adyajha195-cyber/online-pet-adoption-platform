package com.example.pet_adaption;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetAdaptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetAdaptionApplication.class, args);
	}

}
