package com.example.pet_adaption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetAdaptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
